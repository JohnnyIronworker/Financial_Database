CREATE DATABASE IF NOT EXISTS finanse5;
USE finanse5;


CREATE TABLE Inwestorzy (
    inwestor_id INT PRIMARY KEY,
    imie VARCHAR(255),
    nazwisko VARCHAR(255),
    email VARCHAR(255),
    telefon VARCHAR(255)
);

-- Tabela Konta
CREATE TABLE Konta (
    konto_id INT PRIMARY KEY,
    inwestor_id INT,
    saldo DECIMAL(10, 2),
    waluta VARCHAR(255),
    FOREIGN KEY (inwestor_id) REFERENCES Inwestorzy(inwestor_id)
);

-- Tabela InstrumentyFinansowe
CREATE TABLE InstrumentyFinansowe (
    instrument_id INT PRIMARY KEY,
    nazwa VARCHAR(255),
    typ VARCHAR(255),
    cena DECIMAL(10, 2)
);

-- Tabela Rynki
CREATE TABLE Rynki (
    rynek_id INT PRIMARY KEY,
    nazwa VARCHAR(255),
    lokalizacja VARCHAR(255),
    godziny_otwarcia VARCHAR(255),
    godziny_zamkniecia VARCHAR(255)
);

-- Tabela Transakcje
CREATE TABLE Transakcje (
    transakcja_id INT PRIMARY KEY,
    konto_id INT,
    instrument_id INT,
    rynek_id INT,
    data DATE,
    ilosc INT,
    FOREIGN KEY (konto_id) REFERENCES Konta(konto_id),
    FOREIGN KEY (instrument_id) REFERENCES InstrumentyFinansowe(instrument_id),
    FOREIGN KEY (rynek_id) REFERENCES Rynki(rynek_id)
);

-- Tabela Zlecenia
CREATE TABLE Zlecenia (
    zlecenie_id INT PRIMARY KEY,
    konto_id INT,
    instrument_id INT,
    ilosc INT,
    typ_zlecenia VARCHAR(255),
    cena_limitu DECIMAL(10, 2),
    FOREIGN KEY (konto_id) REFERENCES Konta(konto_id),
    FOREIGN KEY (instrument_id) REFERENCES InstrumentyFinansowe(instrument_id)
);

-- Tabela Firmy
CREATE TABLE Firmy (
    firma_id INT PRIMARY KEY,
    nazwa VARCHAR(255),
    sektor VARCHAR(255),
    rynek_id INT,
    FOREIGN KEY (rynek_id) REFERENCES Rynki(rynek_id)
);

-- Tabela Akcje
CREATE TABLE Akcje (
    akcja_id INT PRIMARY KEY,
    instrument_id INT,
    firma_id INT,
    liczba_akcji INT,
    FOREIGN KEY (instrument_id) REFERENCES InstrumentyFinansowe(instrument_id),
    FOREIGN KEY (firma_id) REFERENCES Firmy(firma_id)
);

-- Tabela Obligacje
CREATE TABLE Obligacje (
    obligacja_id INT PRIMARY KEY,
    instrument_id INT,
    firma_id INT,
    wartosc_nominalna DECIMAL(10, 2),
    data_wyplaty DATE,
    FOREIGN KEY (instrument_id) REFERENCES InstrumentyFinansowe(instrument_id),
    FOREIGN KEY (firma_id) REFERENCES Firmy(firma_id)
);

-- Tabela Fundusze
CREATE TABLE Fundusze (
    fundusz_id INT PRIMARY KEY,
    instrument_id INT,
    nazwa VARCHAR(255),
    typ_funduszu VARCHAR(255),
    wartosc_aktywów DECIMAL(10, 2),
    FOREIGN KEY (instrument_id) REFERENCES InstrumentyFinansowe(instrument_id)
);

USE finanse5;

-- Dodanie Inwestorów
INSERT INTO Inwestorzy (inwestor_id, imie, nazwisko, email, telefon)
VALUES (1, 'Jan', 'Kowalski', 'jan.kowalski@email.com', '+48123456789'),
       (2, 'Anna', 'Nowak', 'anna.nowak@email.com', '+48123456788'),
       (3, 'Tomasz', 'Marek', 'tomasz.marek@email.com', '+48123456787'),
       (4, 'Ewa', 'Adamczyk', 'ewa.adamczyk@email.com', '+48123456786'),
       (5, 'Karol', 'Wójcik', 'karol.wojcik@email.com', '+48123456785'),
       (6, 'Monika', 'Kaczmarek', 'monika.kaczmarek@email.com', '+48123456784'),
       (7, 'Marek', 'Borkowski', 'marek.borkowski@email.com', '+48123456783'),
       (8, 'Joanna', 'Kozłowska', 'joanna.kozlowska@email.com', '+48123456782'),
       (9, 'Robert', 'Szymański', 'robert.szymanski@email.com', '+48123456781'),
       (10, 'Maria', 'Dąbrowska', 'maria.dabrowska@email.com', '+48123456780');

-- Dodanie Kont
INSERT INTO Konta (konto_id, inwestor_id, saldo, waluta)
VALUES (1, 1, 10000.00, 'PLN'),
       (2, 2, 15000.00, 'PLN'),
       (3, 3, 20000.00, 'PLN'),
       (4, 4, 25000.00, 'PLN'),
       (5, 5, 30000.00, 'PLN'),
       (6, 6, 35000.00, 'PLN'),
       (7, 7, 40000.00, 'PLN'),
       (8, 8, 45000.00, 'PLN'),
       (9, 9, 50000.00, 'PLN'),
       (10, 10, 55000.00, 'PLN');

-- Dodanie Instrumentów Finansowych
INSERT INTO InstrumentyFinansowe (instrument_id, nazwa, typ, cena)
VALUES (1, 'Akcje XYZ', 'Akcje', 100.00),
       (2, 'Akcje ABC', 'Akcje', 200.00),
       (3, 'Obligacje DEF', 'Obligacje', 300.00),
       (4, 'Obligacje GHI', 'Obligacje', 400.00),
       (5, 'Fundusz JKL', 'Fundusz Inwestycyjny', 500.00),
       (6, 'Fundusz MNO', 'Fundusz Inwestycyjny', 600.00),
       (7, 'Akcje PQR', 'Akcje', 700.00),
       (8, 'Obligacje STU', 'Obligacje', 800.00),
       (9, 'Fundusz VWX', 'Fundusz Inwestycyjny', 900.00),
       (10, 'Akcje YZA', 'Akcje', 1000.00);

-- Dodanie Rynków
INSERT INTO Rynki (rynek_id, nazwa, lokalizacja, godziny_otwarcia, godziny_zamkniecia)
VALUES (1, 'GPW', 'Warszawa', '09:00', '17:30'),
       (2, 'NYSE', 'Nowy Jork', '09:30', '16:00'),
       (3, 'LSE', 'Londyn', '08:00', '16:30'),
       (4, 'NASDAQ', 'Nowy Jork', '09:30', '16:00'),
       (5, 'Euronext', 'Paryż', '09:00', '17:30'),
       (6, 'TSX', 'Toronto', '09:30', '16:00'),
       (7, 'SSE', 'Szanghaj', '09:30', '15:00'),
       (8, 'HKEX', 'Hongkong', '09:30', '16:00'),
       (9, 'BSE', 'Mumbai', '09:15', '15:30'),
       (10, 'ASX', 'Sydney', '10:00', '16:00');
       
-- Dodanie Transakcji
INSERT INTO Transakcje (transakcja_id, konto_id, instrument_id, rynek_id, data, ilosc)
VALUES (1, 1, 1, 1, '2023-01-01', 100),
       (2, 2, 2, 1, '2023-01-02', 150),
       (3, 3, 3, 2, '2023-01-03', 200),
       (4, 4, 4, 2, '2023-01-04', 250),
       (5, 5, 5, 3, '2023-01-05', 300),
       (6, 6, 6, 3, '2023-01-06', 350),
       (7, 7, 7, 4, '2023-01-07', 400),
       (8, 8, 8, 4, '2023-01-08', 450),
       (9, 9, 9, 5, '2023-01-09', 500),
       (10, 10, 10, 5, '2023-01-10', 550);

-- Dodanie Zleceń
INSERT INTO Zlecenia (zlecenie_id, konto_id, instrument_id, ilosc, typ_zlecenia, cena_limitu)
VALUES (1, 1, 1, 100, 'Kupno', 110.00),
       (2, 2, 2, 150, 'Sprzedaż', 210.00),
       (3, 3, 3, 200, 'Kupno', 310.00),
       (4, 4, 4, 250, 'Sprzedaż', 410.00),
       (5, 5, 5, 300, 'Kupno', 510.00),
       (6, 6, 6, 350, 'Sprzedaż', 610.00),
       (7, 7, 7, 400, 'Kupno', 710.00),
       (8, 8, 8, 450, 'Sprzedaż', 810.00),
       (9, 9, 9, 500, 'Kupno', 910.00),
       (10, 10, 10, 550, 'Sprzedaż', 1010.00);

-- Dodanie Firm
INSERT INTO Firmy (firma_id, nazwa, sektor, rynek_id)
VALUES (1, 'Firma XYZ', 'Technologia', 1),
       (2, 'Firma ABC', 'Finanse', 2),
       (3, 'Firma DEF', 'Nieruchomości', 3),
       (4, 'Firma GHI', 'Energia', 4),
       (5, 'Firma JKL', 'Zdrowie', 5),
       (6, 'Firma MNO', 'Konsumencki', 6),
       (7, 'Firma PQR', 'Przemysłowy', 7),
       (8, 'Firma STU', 'Materiały', 8),
       (9, 'Firma VWX', 'Telekomunikacja', 9),
       (10, 'Firma YZA', 'Usługi', 10);

-- Dodanie Akcji
INSERT INTO Akcje (akcja_id, instrument_id, firma_id, liczba_akcji)
VALUES (1, 1, 1, 1000),
       (2, 2, 2, 1500),
       (3, 7, 3, 2000),
       (4, 7, 4, 2500),
       (5, 10, 5, 3000),
       (6, 10, 6, 3500),
       (7, 10, 7, 4000),
       (8, 10, 8, 4500),
       (9, 10, 9, 5000),
       (10, 10, 10, 5500);

-- Dodanie Obligacji
INSERT INTO Obligacje (obligacja_id, instrument_id, firma_id, wartosc_nominalna, data_wyplaty)
VALUES (1, 3, 1, 1000.00, '2023-12-31'),
       (2, 4, 2, 1500.00, '2024-12-31'),
       (3, 8, 3, 2000.00, '2025-12-31'),
       (4, 8, 4, 2500.00, '2026-12-31'),
       (5, 8, 5, 3000.00, '2027-12-31'),
       (6, 8, 6, 3500.00, '2028-12-31'),
       (7, 8, 7, 4000.00, '2029-12-31'),
       (8, 8, 8, 4500.00, '2030-12-31'),
       (9, 8, 9, 5000.00, '2031-12-31'),
       (10, 8, 10, 5500.00, '2032-12-31');

-- Dodanie Funduszy
INSERT INTO Fundusze (fundusz_id, instrument_id, nazwa, typ_funduszu, wartosc_aktywów)
VALUES (1, 5, 'Fundusz JKL', 'Stabilny', 50000.00),
       (2, 6, 'Fundusz MNO', 'Zrównoważony', 60000.00),
       (3, 9, 'Fundusz VWX', 'Akcyjny', 70000.00),
       (4, 9, 'Fundusz YZA', 'Obligacyjny', 80000.00),
       (5, 9, 'Fundusz ABC', 'Pieniężny', 90000.00),
       (6, 9, 'Fundusz DEF', 'Stabilny', 100000.00),
       (7, 9, 'Fundusz GHI', 'Zrównoważony', 110000.00),
       (8, 9, 'Fundusz KLM', 'Akcyjny', 120000.00),
       (9, 9, 'Fundusz NOP', 'Obligacyjny', 130000.00),
       (10, 9, 'Fundusz QRS', 'Pieniężny', 140000.00);

-- Dodanie dodatkowych Inwestorów
INSERT INTO Inwestorzy (inwestor_id, imie, nazwisko, email, telefon)
VALUES (11, 'Piotr', 'Kowalski', 'piotr.kowalski@example.com', '111-111-111'),
       (12, 'Karolina', 'Nowak', 'karolina.nowak@example.com', '222-222-222'),
       (13, 'Michał', 'Wiśniewski', 'michal.wisniewski@example.com', '333-333-333'),
       (14, 'Anna', 'Zalewska', 'anna.zalewska@example.com', '444-444-444'),
       (15, 'Jakub', 'Górski', 'jakub.gorski@example.com', '555-555-555');

-- Dodanie dodatkowych Kont
INSERT INTO Konta (konto_id, inwestor_id, saldo, waluta)
VALUES (11, 11, 5000.00, 'PLN'),
       (12, 12, 6000.00, 'USD'),
       (13, 13, 7000.00, 'EUR'),
       (14, 14, 8000.00, 'GBP'),
       (15, 15, 9000.00, 'JPY');

-- Dodanie dodatkowych Transakcji
INSERT INTO Transakcje (transakcja_id, konto_id, instrument_id, rynek_id, data, ilosc)
VALUES (11, 11, 1, 1, '2023-06-06', 50),
       (12, 12, 2, 2, '2023-06-07', 60),
       (13, 13, 3, 3, '2023-06-08', 70),
       (14, 14, 4, 4, '2023-06-09', 80),
       (15, 15, 5, 5, '2023-06-10', 90);

-- Dodanie dodatkowych Zleceń
INSERT INTO Zlecenia (zlecenie_id, konto_id, instrument_id, ilosc, typ_zlecenia, cena_limitu)
VALUES (11, 11, 1, 100, 'KUPNO', 5000.00),
       (12, 12, 2, 200, 'SPRZEDAŻ', 6000.00),
       (13, 13, 3, 300, 'KUPNO', 7000.00),
       (14, 14, 4, 400, 'SPRZEDAŻ', 8000.00),
       (15, 15, 5, 500, 'KUPNO', 9000.00);
