DELIMITER //

CREATE PROCEDURE WeryfikacjaKlienta(IN imie VARCHAR(50), IN nazwisko VARCHAR(50))
BEGIN
    SELECT * 
    FROM Transakcje
    INNER JOIN Konta ON Transakcje.konto_id = Konta.konto_id
    WHERE Konta.inwestor_id IN (
        SELECT Inwestorzy.inwestor_id 
        FROM Inwestorzy
        WHERE Inwestorzy.imie = imie AND Inwestorzy.nazwisko = nazwisko
    );
END //

DELIMITER ;

call WeryfikacjaKlienta('Jan','Kowalski'); -- Procedura dla przykładu z poprzedniego rozdziału 

DELIMITER //


DELIMITER //

CREATE FUNCTION `LiczbaTransakcji`(investorID INT) RETURNS INT -- Przykładowa funkcja
DETERMINISTIC
BEGIN
    DECLARE transactionCount INT;

    SELECT COUNT(*) INTO transactionCount
    FROM Transakcje
    INNER JOIN Konta ON Transakcje.konto_id = Konta.konto_id
    WHERE Konta.inwestor_id = investorID;

    RETURN transactionCount;
END//

DELIMITER ;

SELECT LiczbaTransakcji(1);



CREATE VIEW Podsumowanie_Transakcji_Inwestorów AS -- Przykładowa perspektywa
SELECT Inwestorzy.imie, Inwestorzy.nazwisko, COUNT(*) AS TotalTransactions
FROM Inwestorzy
JOIN Konta ON Inwestorzy.inwestor_id = Konta.inwestor_id
JOIN Transakcje ON Konta.konto_id = Transakcje.konto_id
GROUP BY Inwestorzy.inwestor_id;

SELECT * FROM Podsumowanie_Transakcji_Inwestorów;

