SELECT * FROM Inwestorzy; -- Pierwsze zapytanie, wszystkie wiersze wszystkich kolumn dla Inwestorzy

SELECT COUNT(*) as 'Panie.inwestorki' -- Drugie zapytanie, zlicza nam k!#@biety
FROM Inwestorzy
WHERE imie LIKE '%a';

SELECT * -- Trzecie zapytanie, wyszukuje nam transakcje Jan Kowalskiego 
FROM Transakcje
INNER JOIN Konta ON Transakcje.konto_id = Konta.konto_id
WHERE Konta.inwestor_id IN (
    SELECT Inwestorzy.inwestor_id 
    FROM Inwestorzy
    WHERE Inwestorzy.imie = 'Jan' AND Inwestorzy.nazwisko = 'Kowalski'
);

SELECT SUM(cena) as 'W.calkowita' FROM InstrumentyFinansowe; -- czwarte zapytanie suma wartosci portfela

SELECT Firmy.nazwa, SUM(Akcje.liczba_akcji) as 'Akcje.wszystkie' -- piąte zapytanie ilość wyemitowanych akcji przez każdą firmę
FROM Akcje 
INNER JOIN Firmy ON Akcje.firma_id = Firmy.firma_id 
GROUP BY Firmy.nazwa;